"""
PARABOLA PLATFORMER - Path Tester
Precalculus 11 - Chapter 4 Applied Task

Students place their items (short spikes, wing, coin), then type Pip's moves:
walks (y = k) and jumps/digs (parabolas in vertex, factored or standard form).
The game checks every move against the project's game rules. It never solves
anything for the student.

Runs on desktop Python with pygame (python main.py), and in the browser with
pygbag (pygbag <folder containing this file>).

Typing shortcuts
  (x-6)2   or (x-6)^2   or (x-6)²   ->  (x - 6) squared
  x2                                  ->  x squared
  sqrt(6)  or sqrt6  or r6  or √6     ->  root 6
  4 + sqrt(4), 4+2sqrt(6), (8+sqrt(24))/2, 48+r51.2  all work as x-values
"""
import asyncio
import json
import math
import re
import sys
import time

import pygame

# ----------------------------------------------------------------------------
# Window and colours
# ----------------------------------------------------------------------------
W, H = 1280, 960
pygame.init()
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("Parabola Platformer - Path Tester")
clock = pygame.time.Clock()
pygame.key.set_repeat(400, 35)
try:
    pygame.key.start_text_input()
except Exception:
    pass

PAPER = (244, 239, 226)
CARD = (255, 253, 247)
WHITE = (255, 255, 255)
INK = (31, 29, 26)
MUTED = (106, 100, 88)
LINE = (221, 213, 193)
TITLE = (229, 83, 47)
TEAL = (47, 158, 143)
YELLOW = (249, 214, 92)
MINT = (147, 220, 207)
ROSE = (245, 181, 169)
SKYTAG = (182, 220, 242)
PINK = (214, 51, 108)
BLUE = (42, 127, 168)
PURPLE = (138, 92, 214)
ORANGE = (232, 137, 28)
OKC = (44, 138, 75)
BADC = (195, 53, 43)
WARNC = (168, 107, 18)
GREYBTN = (189, 182, 166)

SKY = (234, 244, 251)
GROUND = (207, 165, 122)
GROUND_DK = (185, 143, 99)
GRASS = (63, 155, 75)
ROCK = (123, 106, 88)
LAVA = (240, 138, 60)
LAVA_DK = (212, 96, 42)
PIPE = (67, 173, 79)
PIPE_LT = (140, 205, 146)
PIPE_DK = (31, 94, 39)
SPIKE = (201, 204, 213)
SPIKE_DK = (70, 74, 84)
DOOR = (234, 138, 62)
DOOR_DK = (140, 63, 23)
COIN = (245, 197, 53)
COIN_DK = (201, 147, 15)
ZONE = (47, 143, 134)

KIND_COLOR = {"walk": PURPLE, "jump": PINK, "dig": BLUE, "line": ORANGE, "bad": BADC}
MSG_COLOR = {"ok": (OKC, (238, 248, 241)), "bad": (BADC, (253, 240, 238)),
             "warn": (WARNC, (253, 246, 230)), "info": (LINE, WHITE)}

# ----------------------------------------------------------------------------
# Fixed map (from the project booklet)
# ----------------------------------------------------------------------------
START_END = 46      # start ground y = 0 for x <= 46
PIT_END = 52        # lava pit 46 < x < 52, high ground y = 2 for x >= 52
HIGH = 2
LAVA_TOP = -11
PIPE1, PIPE2, PIPE_BOTTOM = 58, 60, 4
LS1, LS2, LS_TIP = 70, 80, 3
DOOR_X = 104
MAP_TOP, BEDROCK = 20, -15
E = 1e-9

VIEWS = {
    "full": dict(x1=-1.5, x2=111, y1=-16, y2=21, step=5, label="Full map"),
    "r1": dict(x1=-0.5, x2=48.5, y1=-15.5, y2=20.5, step=2, label="Route 1  0-48"),
    "r2": dict(x1=29.5, x2=62.5, y1=-15.5, y2=20.5, step=2, label="Route 2  30-62"),
    "r3": dict(x1=51.5, x2=108.5, y1=-15.5, y2=20.5, step=2, label="Route 3  52-108"),
}

# ----------------------------------------------------------------------------
# Fonts and text (cached, since rendering text is slow in the browser)
# ----------------------------------------------------------------------------
_fonts = {}
_text_cache = {}


def font(sz):
    f = _fonts.get(sz)
    if f is None:
        f = pygame.font.Font(None, sz)
        _fonts[sz] = f
    return f


def render(s, sz, color):
    key = (s, sz, color)
    img = _text_cache.get(key)
    if img is None:
        if len(_text_cache) > 1500:
            _text_cache.clear()
        img = font(sz).render(s, True, color)
        _text_cache[key] = img
    return img


def text(surf, s, pos, sz=20, color=INK, anchor="topleft"):
    img = render(s, sz, color)
    r = img.get_rect(**{anchor: pos})
    surf.blit(img, r)
    return r


def wrap(s, sz, width):
    f = font(sz)
    out = []
    for para in s.split("\n"):
        words = para.split(" ")
        line = ""
        for w in words:
            test = (line + " " + w).strip()
            if f.size(test)[0] <= width or not line:
                line = test
            else:
                out.append(line)
                line = w
        out.append(line)
    return out


# ----------------------------------------------------------------------------
# Equation parser
# ----------------------------------------------------------------------------
DIG = "0123456789"


class ParseError(Exception):
    pass


def tokenize(src):
    s = str(src)
    for a, b in (("−", "-"), ("–", "-"), ("—", "-"), ("×", "*"),
                 ("·", "*"), ("∙", "*"), ("÷", "/")):
        s = s.replace(a, b)
    s = s.strip()
    s = re.sub(r"^(y|f\s*\(\s*x\s*\))\s*=\s*", "", s, flags=re.I)
    toks = []
    n = len(s)

    def squareable(i):
        if i < n and s[i] in DIG:
            j = i
            while j < n and (s[j] in DIG or s[j] == "."):
                j += 1
            if s[i:j] == "2":
                toks.append({"t": "^"})
                toks.append({"t": "num", "v": 2.0, "text": "2"})
                return j
            raise ParseError('A number right after ")" or "x" means a power, and only 2 '
                             '(squared) works. To multiply, put the number in front, like 3(x - 1).')
        return i

    i = 0
    while i < n:
        c = s[i]
        if c == " ":
            i += 1
            continue
        if c in DIG or c == ".":
            j = i
            while j < n and (s[j] in DIG or s[j] == "."):
                j += 1
            t = s[i:j]
            if t == "." or t.count(".") > 1:
                raise ParseError('"%s" is not a number.' % t)
            toks.append({"t": "num", "v": float(t), "text": t})
            i = j
            continue
        if c in "xX":
            toks.append({"t": "x"})
            i = squareable(i + 1)
            continue
        if c in "([":
            toks.append({"t": "("})
            i += 1
            continue
        if c in ")]":
            toks.append({"t": ")"})
            i = squareable(i + 1)
            continue
        if c == "²":
            toks.append({"t": "^"})
            toks.append({"t": "num", "v": 2.0, "text": "2"})
            i += 1
            continue
        if c in "+-*/^":
            toks.append({"t": c})
            i += 1
            continue
        if c == "√":
            toks.append({"t": "sqrt"})
            i += 1
            continue
        rest = s[i:].lower()
        if rest.startswith("sqrt") or rest.startswith("root"):
            toks.append({"t": "sqrt"})
            i += 4
            continue
        if c in "rR":
            toks.append({"t": "sqrt"})
            i += 1
            continue
        if c == "=":
            raise ParseError('Type only the right side, after "y =".')
        raise ParseError('Pip does not understand "%s".' % c)
    return toks


def parse(src):
    toks = tokenize(src)
    if not toks:
        raise ParseError("empty")
    p = [0]

    def peek():
        return toks[p[0]] if p[0] < len(toks) else None

    def nxt():
        k = peek()
        p[0] += 1
        return k

    def starts(k):
        return k is not None and k["t"] in ("x", "(", "sqrt")

    def expr():
        node = term()
        while peek() is not None and peek()["t"] in ("+", "-"):
            op = nxt()["t"]
            node = {"t": "add" if op == "+" else "sub", "a": node, "b": term()}
        return node

    def term():
        node = unary()
        while True:
            k = peek()
            if k is not None and k["t"] in ("*", "/"):
                nxt()
                node = {"t": "mul" if k["t"] == "*" else "div", "a": node, "b": unary()}
            elif starts(k):
                node = {"t": "mul", "a": node, "b": power(), "imp": True}
            elif k is not None and k["t"] == "num":
                raise ParseError("A number can't follow straight after that. "
                                 "Put numbers in front, or add an operation.")
            else:
                break
        return node

    def unary():
        k = peek()
        if k is not None and k["t"] == "-":
            nxt()
            return {"t": "neg", "a": unary()}
        if k is not None and k["t"] == "+":
            nxt()
            return unary()
        return power()

    def power():
        b = primary()
        if peek() is not None and peek()["t"] == "^":
            nxt()
            b = {"t": "pow", "a": b, "b": unary()}
        return b

    def primary():
        k = nxt()
        if k is None:
            raise ParseError("The equation stops too soon.")
        t = k["t"]
        if t == "num":
            return {"t": "num", "v": k["v"], "text": k["text"]}
        if t == "x":
            return {"t": "x"}
        if t == "(":
            e = expr()
            c = nxt()
            if c is None or c["t"] != ")":
                raise ParseError('A bracket is missing its ")".')
            return {"t": "paren", "a": e}
        if t == "sqrt":
            return {"t": "sqrt", "a": primary()}
        if t == ")":
            raise ParseError('There is an extra ")".')
        raise ParseError('"%s" is in an odd spot.' % t)

    ast = expr()
    if p[0] < len(toks):
        raise ParseError('There is an extra ")".' if toks[p[0]]["t"] == ")"
                         else "Something is off near the end.")
    return ast


def _ev(n, x):
    t = n["t"]
    if t == "num":
        return n["v"]
    if t == "x":
        return x
    if t == "paren":
        return _ev(n["a"], x)
    if t == "neg":
        return -_ev(n["a"], x)
    if t == "sqrt":
        return math.sqrt(_ev(n["a"], x))
    a = _ev(n["a"], x)
    b = _ev(n["b"], x)
    if t == "add":
        return a + b
    if t == "sub":
        return a - b
    if t == "mul":
        return a * b
    if t == "div":
        return a / b
    if t == "pow":
        return math.pow(a, b)
    return float("nan")


def ev(n, x):
    try:
        return float(_ev(n, x))
    except (ValueError, ZeroDivisionError, OverflowError):
        return float("nan")


def has_x(n):
    if not isinstance(n, dict):
        return False
    if n["t"] == "x":
        return True
    return has_x(n.get("a")) or has_x(n.get("b"))


def finite(*vals):
    return all(v is not None and math.isfinite(v) for v in vals)


def quad_of(ast):
    c = ev(ast, 0)
    s1 = ev(ast, 1)
    s2 = ev(ast, 2)
    a = (s2 - 2 * s1 + c) / 2
    b = s1 - c - a
    if not finite(a, b, c):
        return None
    for t in (-3.7, 7.3, 13.1, 55.5, 104, -14.2):
        v = ev(ast, t)
        q = a * t * t + b * t + c
        if not math.isfinite(v) or abs(v - q) > 1e-6 * (1 + abs(v)):
            return None
    if abs(a) < 1e-12:
        a = 0.0
    if abs(b) < 1e-12:
        b = 0.0
    return {"a": a, "b": b, "c": c}


def pretty(n):
    """Turn a parsed expression back into readable math text."""
    t = n["t"]
    if t == "num":
        return n["text"]
    if t == "x":
        return "x"
    if t == "paren":
        return "(" + pretty(n["a"]) + ")"
    if t == "neg":
        return "−" + pretty(n["a"])
    if t == "add":
        return pretty(n["a"]) + " + " + pretty(n["b"])
    if t == "sub":
        return pretty(n["a"]) + " − " + pretty(n["b"])
    if t == "mul":
        if n.get("imp"):
            return pretty(n["a"]) + pretty(n["b"])
        return pretty(n["a"]) + " · " + pretty(n["b"])
    if t == "div":
        return pretty(n["a"]) + "/" + pretty(n["b"])
    if t == "pow":
        b = n["b"]
        if b["t"] == "num" and b["text"] == "2":
            return pretty(n["a"]) + "²"
        return pretty(n["a"]) + "^" + pretty(b)
    if t == "sqrt":
        a = n["a"]
        if a["t"] == "paren" and a["a"]["t"] in ("num", "x"):
            a = a["a"]
        return "√" + pretty(a)
    return "?"


def rounded_bits(src):
    return re.findall(r"\d*\.\d{4,}", str(src))


def is_int(v):
    return abs(v - round(v)) < 1e-9


def nfmt(v, d=3):
    if is_int(v):
        s = str(int(round(v)))
    else:
        s = ("%.*f" % (d, v)).rstrip("0").rstrip(".")
    return s.replace("-", "−")


def y_is(v):
    return ("y = " + nfmt(v)) if is_int(v) else ("y of about " + nfmt(v))


def coord_y(v):
    return nfmt(v) if is_int(v) else "about " + nfmt(v)


# ----------------------------------------------------------------------------
# State
# ----------------------------------------------------------------------------
class State:
    def __init__(self):
        self.mode = "main"
        self.view = "full"
        self.zones = True
        self.kind = "jump"
        self.placed = False
        self.items = {
            "spikes": {"x1": None, "x2": None, "h": None},
            "wing": {"x": None, "w": None, "b": None, "h": None},
            "coin": {"type": "", "x": None, "w": None, "b": None, "h": None},
        }
        self.paths = {"main": [], "booster": []}
        self.attempt = None
        self.anim = None
        self.msgs = []
        self.hover = None
        self.scroll = 0


S = State()


def spike_sets():
    s = S.items["spikes"]
    out = []
    if finite(s["x1"], s["x2"], s["h"]) and s["x2"] > s["x1"]:
        out.append(dict(x1=s["x1"], x2=s["x2"], tip=s["h"], base=0, name="your short spikes"))
    out.append(dict(x1=LS1, x2=LS2, tip=LS_TIP, base=HIGH, name="the long spikes"))
    return out


def item_list():
    out = []
    for key in ("wing", "coin"):
        it = S.items[key]
        if finite(it["x"], it["w"], it["b"], it["h"]):
            out.append(dict(id=key, x=it["x"], w=it["w"], b=it["b"], h=it["h"],
                            mid=it["x"] + it["w"] / 2, top=it["b"] + it["h"]))
    return out


def ground_top(x):
    if x <= START_END + E:
        return 0
    if x < PIT_END - E:
        return LAVA_TOP
    return HIGH


def surface_y(x):
    if x <= START_END + E:
        return 0
    if x < PIT_END - E:
        return None
    return HIGH


def start_of(mode):
    P = S.paths[mode]
    if not P:
        return dict(x=0.0, y=0.0, xs="0", ys="0")
    last = P[-1]
    return dict(x=last["xEnd"], y=last["yEnd"], xs=last["endS"], ys=coord_y(last["yEnd"]))


def won(mode):
    P = S.paths[mode]
    if not P:
        return False
    last = P[-1]
    return abs(last["xEnd"] - DOOR_X) < E and abs(last["yEnd"] - HIGH) < 1e-7


# ----------------------------------------------------------------------------
# Building and checking one piece of the path
# ----------------------------------------------------------------------------
def build_piece(mode, kind, eq_text, end_text):
    st = start_of(mode)
    try:
        end_ast = parse(end_text)
    except ParseError as e:
        return None, ("Type the x-value where this piece ends." if str(e) == "empty"
                      else "Ending x: " + str(e))
    if has_x(end_ast):
        return None, "The ending x has to be a number (like 10 or 4 + 2sqrt(6)), not an expression with x."
    x_end = ev(end_ast, 0)
    if not math.isfinite(x_end):
        return None, "Pip can't work out that ending x. Check for a root of a negative or a divide by 0."
    pc = dict(kind=kind, mode=mode, x0=st["x"], y0=st["y"], x0s=st["xs"], y0s=st["ys"],
              xEnd=x_end, endText=end_text, endS=pretty(end_ast), eqText="", eqS="")
    if kind == "walk":
        k = st["y"]
        pc["f"] = lambda x, k=k: k
        pc["coef"] = dict(a=0.0, b=0.0, c=k)
        return pc, None
    try:
        ast = parse(eq_text)
    except ParseError as e:
        return None, ('Type the equation after "y =".' if str(e) == "empty" else "Equation: " + str(e))
    q = quad_of(ast)
    if q is None:
        return None, ("That isn't a parabola Pip can follow. Check your brackets, and make sure "
                      "it's a quadratic (x squared is the highest power).")
    pc["eqText"] = eq_text
    pc["eqS"] = "y = " + pretty(ast)
    pc["coef"] = q
    pc["f"] = lambda x, ast=ast: ev(ast, x)
    if mode == "booster":
        if q["a"] != 0:
            return None, "The booster flies in straight lines. Use a linear equation, like y = mx + b."
        pc["kind"] = "line"
    else:
        if q["a"] == 0 and q["b"] == 0:
            return None, 'That is a flat line, which is a walk. Choose "Walk" for flat pieces.'
        if q["a"] == 0:
            return None, ("That is a slanted straight line. On the main path Pip only walks (flat) "
                          "or moves on parabolas. Slanted lines are for the booster.")
        pc["kind"] = "jump" if q["a"] < 0 else "dig"
    return pc, None


def simulate(pc):
    x0, y0, x_end, kind, f, mode = pc["x0"], pc["y0"], pc["xEnd"], pc["kind"], pc["f"], pc["mode"]
    res = dict(ok=True, samples=[], collected=[], msgs=[], crash=None)

    def fail_now(t):
        res["ok"] = False
        res["msgs"].append(("bad", "NOT YET", t))
        return res

    if not x_end > x0 + E:
        return fail_now("Pip only moves right. This piece starts at x = %s, so it has to end at a bigger x." % pc["x0s"])
    if x_end > DOOR_X + E:
        return fail_now("The door is at x = 104, so Pip's path ends there. End this piece at x = 104 or sooner.")
    fy0 = f(x0)
    if not abs(fy0 - y0) <= 1e-7:
        return fail_now("Pip is standing at (%s, %s). At x = %s, your equation gives %s, so this piece "
                        "doesn't start where Pip is." % (pc["x0s"], pc["y0s"], pc["x0s"], y_is(fy0)))
    if kind in ("jump", "dig"):
        p = -pc["coef"]["b"] / (2 * pc["coef"]["a"])
        if not p > x0 + 1e-9:
            if kind == "jump":
                return fail_now("A jump goes up first, so its vertex has to be to the right of the takeoff "
                                "(x = %s). This one heads straight down." % pc["x0s"])
            return fail_now("A dig goes down first, so its vertex has to be to the right of where Pip starts "
                            "(x = %s). This one heads straight up." % pc["x0s"])
    if kind == "dig" and x0 < PIT_END and x_end > START_END + E:
        return fail_now("No digging under the lava pit (46 < x < 52). Pip has to jump it.")

    end_note = None
    yE = f(x_end)
    if kind in ("jump", "dig"):
        sy = surface_y(x_end)
        if sy is None:
            end_note = (False, "x = %s is over the lava pit. There is no ground to land on there." % pc["endS"])
        else:
            d = yE - sy
            if abs(d) <= 1e-7:
                pass
            elif abs(d) < 0.05:
                end_note = (True, "So close! At x = %s, Pip is about %s %s the ground. That usually means the "
                                  "landing x was rounded. Use the exact value (a fraction or sqrt)."
                            % (pc["endS"], nfmt(abs(d), 4), "above" if d > 0 else "below"))
            else:
                end_note = (False, "At x = %s, your parabola gives %s, but the ground there is at y = %d. "
                                   "Pip would end up %s. Check your landing x."
                            % (pc["endS"], y_is(yE), sy, "floating in the air" if d > 0 else "stuck underground"))
    elif kind == "line":
        if abs(x_end - DOOR_X) < E:
            if abs(yE - HIGH) > 1e-7:
                end_note = (False, "At the door (x = 104) your line gives %s. The door sits on the ground at y = 2." % y_is(yE))
        elif yE <= ground_top(x_end) + E:
            end_note = (False, "This line ends on or below the ground. During the booster, Pip only touches "
                               "the ground at the door (104, 2).")

    N = max(300, int(math.ceil((x_end - x0) * 30)))
    xs = [x0 + (x_end - x0) * i / N for i in range(N + 1)]
    its = item_list() if mode == "main" else []
    crit = [46, 52, 58, 60, 70, 80]
    for s in spike_sets():
        crit += [s["x1"], s["x2"]]
    for it in its:
        crit.append(it["mid"])
    for c in crit:
        if x0 + E < c < x_end - E:
            xs.append(c)
    xs.sort()
    got = []
    for x in xs:
        feet = f(x)
        head = feet + 1
        inner = x0 + E < x < x_end - E
        res["samples"].append((x, feet))
        hit = None
        if head > MAP_TOP + E:
            hit = "Pip's head went above the top of the map (y = 20)."
        elif feet < BEDROCK - E:
            hit = "Pip hit bedrock. Feet have to stay at y >= −15."
        elif mode == "main" and PIPE1 - E <= x <= PIPE2 + E and head > PIPE_BOTTOM + E:
            hit = "Pip bumped the pipe. Under the pipe (58 ≤ x ≤ 60), Pip's head has to stay at y ≤ 4."
        if hit is None:
            for s in spike_sets():
                if x < s["x1"] - E or x > s["x2"] + E:
                    continue
                if kind == "dig":
                    if head > s["base"] - E:
                        hit = ("Pip touched %s. During a dig, Pip's head has to stay below the ground (y < %d) "
                               "at x = %d and x = %d." % (s["name"], s["base"], s["x1"], s["x2"]))
                elif kind == "walk":
                    hit = "Pip walked into %s." % s["name"]
                elif feet <= s["tip"] + E:
                    hit = ("Pip touched %s. Pip's feet have to stay above the tips (y > %d) at x = %d and x = %d."
                           % (s["name"], s["tip"], s["x1"], s["x2"]))
                if hit:
                    break
        if hit is None:
            in_pit = START_END + E < x < PIT_END - E
            if kind == "walk":
                if in_pit:
                    hit = "Pip walked off the edge into the lava pit."
            elif kind == "dig":
                if inner and feet >= ground_top(x) - E:
                    hit = ("Pip popped out of the ground before reaching x = %s. A dig stays underground "
                           "until it lands." % pc["endS"])
            else:
                if in_pit:
                    if feet <= LAVA_TOP + E:
                        hit = "The booster dipped into the lava." if kind == "line" else "Pip fell into the lava."
                elif abs(x - PIT_END) < E and x > x0 + E:
                    if (feet < HIGH - E) if kind == "jump" else (feet <= HIGH + E):
                        hit = ("Pip hit the far wall of the lava pit. At x = 52, Pip's feet need y ≥ 2."
                               if kind == "jump" else "The booster clipped the edge of the high ground at x = 52.")
                elif inner and feet <= ground_top(x) + E:
                    hit = ("Pip hit the ground before reaching x = %s." % pc["endS"] if kind == "jump"
                           else "The booster touched the ground. Pip can only touch the ground at the door.")
        if hit is None:
            for it in its:
                if abs(x - it["mid"]) < 1e-9 and it["b"] - 1 - E <= feet <= it["top"] + E and it["id"] not in got:
                    got.append(it["id"])
        if hit:
            res["ok"] = False
            res["crash"] = (x, feet)
            if end_note and end_note[0]:
                res["msgs"].append(("bad", "ALMOST", end_note[1]))
            else:
                res["msgs"].append(("bad", "OUCH", hit))
                if end_note:
                    res["msgs"].append(("warn", "ALSO", end_note[1]))
            break
    res["collected"] = got
    if res["ok"] and end_note:
        res["ok"] = False
        res["msgs"].append(("bad", "ALMOST" if end_note[0] else "NOT YET", end_note[1]))
    return res


def ending_warning(p):
    if p["kind"] not in ("jump", "dig"):
        return ""

    def cov(a, b):
        return p["x0"] <= a + E and p["xEnd"] >= b - E

    sp = S.items["spikes"]
    if cov(LS1, LS2) and not (80 - E <= p["xEnd"] <= 104 + E):
        return "Route 3 has to land at 80 ≤ x ≤ 104."
    if cov(START_END, PIT_END) and not (PIT_END - E <= p["xEnd"] < PIPE1 - E):
        return "Route 2 has to land on the high ground before the pipe (52 ≤ x < 58)."
    if finite(sp["x1"], sp["x2"]) and cov(sp["x1"], sp["x2"]) and p["xEnd"] > START_END + E:
        return "Route 1 has to land by x = 46, before the lava pit."
    return ""


def collected_all():
    s = set()
    for p in S.paths["main"]:
        s.update(p.get("collected", []))
    return s


# ----------------------------------------------------------------------------
# Text fields
# ----------------------------------------------------------------------------
FOCUS = [None]


class Field:
    def __init__(self, numeric=False, placeholder=""):
        self.text = ""
        self.cur = 0
        self.numeric = numeric
        self.placeholder = placeholder
        self.rect = pygame.Rect(0, 0, 0, 0)
        self.sz = 26
        self.on_change = None
        self.on_enter = None
        self.offset = 0

    def set(self, t):
        self.text = t
        self.cur = len(t)
        if self.on_change:
            self.on_change()

    def insert(self, s):
        if self.numeric:
            s = "".join(ch for ch in s if ch in DIG or ch == "-")
            if not s:
                return
        self.text = self.text[:self.cur] + s + self.text[self.cur:]
        self.cur += len(s)
        if self.on_change:
            self.on_change()

    def key(self, e):
        k = e.key
        if k == pygame.K_BACKSPACE:
            if self.cur > 0:
                self.text = self.text[:self.cur - 1] + self.text[self.cur:]
                self.cur -= 1
                if self.on_change:
                    self.on_change()
        elif k == pygame.K_DELETE:
            if self.cur < len(self.text):
                self.text = self.text[:self.cur] + self.text[self.cur + 1:]
                if self.on_change:
                    self.on_change()
        elif k == pygame.K_LEFT:
            self.cur = max(0, self.cur - 1)
        elif k == pygame.K_RIGHT:
            self.cur = min(len(self.text), self.cur + 1)
        elif k == pygame.K_HOME:
            self.cur = 0
        elif k == pygame.K_END:
            self.cur = len(self.text)
        elif k in (pygame.K_RETURN, pygame.K_KP_ENTER):
            if self.on_enter:
                self.on_enter()
        else:
            return False
        return True

    def click(self, mx):
        f = font(self.sz)
        rel = mx - (self.rect.x + 10) + self.offset
        best, bestd = 0, 1e9
        for i in range(len(self.text) + 1):
            d = abs(f.size(self.text[:i])[0] - rel)
            if d < bestd:
                best, bestd = i, d
        self.cur = best
        FOCUS[0] = self

    def draw(self, rect):
        self.rect = pygame.Rect(rect)
        r = self.rect
        focused = FOCUS[0] is self
        pygame.draw.rect(screen, WHITE, r, border_radius=8)
        pygame.draw.rect(screen, TEAL if focused else INK, r, 3 if focused else 2, border_radius=8)
        f = font(self.sz)
        inner_w = r.w - 20
        cur_px = f.size(self.text[:self.cur])[0]
        if cur_px - self.offset > inner_w:
            self.offset = cur_px - inner_w
        if cur_px - self.offset < 0:
            self.offset = cur_px
        if f.size(self.text)[0] <= inner_w:
            self.offset = 0
        old = screen.get_clip()
        screen.set_clip(r.inflate(-8, -4))
        if self.text:
            text(screen, self.text, (r.x + 10 - self.offset, r.centery), self.sz, INK, "midleft")
        elif not focused:
            text(screen, self.placeholder, (r.x + 10, r.centery), self.sz, (170, 165, 155), "midleft")
        if focused and (pygame.time.get_ticks() // 530) % 2 == 0:
            cx = r.x + 10 + cur_px - self.offset
            pygame.draw.line(screen, INK, (cx, r.y + 8), (cx, r.bottom - 8), 2)
        screen.set_clip(old)
        hit(r, lambda: self.click(pygame.mouse.get_pos()[0]))


eq_field = Field(placeholder="-1/4(x-6)2+4")
end_field = Field(placeholder="10")
item_fields = {k: Field(numeric=True) for k in ("sx1", "sx2", "wx", "wb", "cx", "cb")}
for _f in item_fields.values():
    _f.sz = 24
ITEM_KEYS = {"sx1": ("spikes", "x1"), "sx2": ("spikes", "x2"), "wx": ("wing", "x"),
             "wb": ("wing", "b"), "cx": ("coin", "x"), "cb": ("coin", "b")}


def _item_changed(key):
    def fn():
        g, k = ITEM_KEYS[key]
        try:
            S.items[g][k] = int(item_fields[key].text)
        except ValueError:
            S.items[g][k] = None
        save()
    return fn


for _k in ITEM_KEYS:
    item_fields[_k].on_change = _item_changed(_k)

# ----------------------------------------------------------------------------
# Actions
# ----------------------------------------------------------------------------
def go():
    S.anim = None
    mode = S.mode
    if won(mode):
        S.msgs = [("info", "", "Pip is already through the door. Undo a move to change the ending.")]
        return
    kind = "line" if mode == "booster" else S.kind
    pc, err = build_piece(mode, kind, eq_field.text, end_field.text)
    if err:
        S.msgs = [("bad", "CHECK THIS", err)]
        S.attempt = None
        return
    res = simulate(pc)
    warns = []
    rb = rounded_bits(eq_field.text) + rounded_bits(end_field.text)
    if rb:
        warns.append(("warn", "KEEP IT EXACT", "%s looks rounded. Keep a and every landing point exact: a "
                      "decimal only if it ends (like -0.04), otherwise a fraction or root." % rb[0]))
    if res["ok"]:
        pc["samples"] = res["samples"]
        pc["collected"] = res["collected"]
        pc["yEnd"] = pc["f"](pc["xEnd"])
        S.paths[mode].append(pc)
        S.attempt = None
        ms = []
        where = "(%s, %s)" % (pc["endS"], coord_y(pc["yEnd"]))
        if pc["kind"] == "walk":
            ms.append(("ok", "NICE", "Pip walked from x = %s to x = %s." % (pc["x0s"], pc["endS"])))
        else:
            verb = {"jump": "Pip landed at ", "dig": "Pip dug through and came up at ",
                    "line": "The booster reached "}[pc["kind"]]
            ms.append(("ok", "NICE", verb + where + "."))
        ew = ending_warning(pc)
        if ew:
            ms.append(("warn", "CHECK THE ENDING", ew))
        for c in pc["collected"]:
            ms.append(("ok", "GOT IT", "Pip grabbed the %s!" % c))
        if won(mode):
            if mode == "main":
                miss = [i for i in ("wing", "coin") if i not in collected_all()]
                if miss:
                    ms.insert(0, ("warn", "AT THE DOOR", "Pip reached the door, but missed the %s. "
                                  "The game counts that as broken." % " and the ".join(miss)))
                else:
                    ms.insert(0, ("ok", "LEVEL CLEAR", "Pip reached the door with the wing and the coin."))
            else:
                n = len(S.paths["booster"])
                if n == 2:
                    ms.insert(0, ("ok", "BOOSTED", "The booster made it to the door in two straight lines."))
                else:
                    ms.insert(0, ("warn", "AT THE DOOR", "The booster reached the door, but it should use "
                                  "exactly two lines (you used %d)." % n))
        S.msgs = ms + warns
        eq_field.set("")
        end_field.set("")
        start_anim([pc], False)
        S.scroll = 10 ** 6
    else:
        S.attempt = dict(samples=res["samples"], crash=res["crash"])
        S.msgs = res["msgs"] + warns
        if res["samples"]:
            start_anim([S.attempt], False)
    save()


eq_field.on_enter = go
end_field.on_enter = go

_arm = {"reset": 0.0, "items": 0.0}


def undo():
    P = S.paths[S.mode]
    if P:
        P.pop()
    S.attempt = None
    S.anim = None
    S.msgs = []
    save()


def reset():
    if not S.paths[S.mode] and not S.attempt:
        return
    if time.time() - _arm["reset"] > 3:
        _arm["reset"] = time.time()
        return
    _arm["reset"] = 0
    S.paths[S.mode] = []
    S.attempt = None
    S.anim = None
    S.msgs = []
    save()


def replay():
    P = S.paths[S.mode]
    if P:
        S.attempt = None
        start_anim(list(P), True)


def edit_items():
    has = S.paths["main"] or S.paths["booster"]
    if has and time.time() - _arm["items"] > 3:
        _arm["items"] = time.time()
        return
    _arm["items"] = 0
    S.paths = {"main": [], "booster": []}
    S.attempt = None
    S.anim = None
    S.msgs = []
    S.placed = False
    S.mode = "main"
    save()


def set_mode(m):
    S.mode = m
    S.attempt = None
    S.anim = None
    S.msgs = []
    eq_field.set("")
    end_field.set("")
    S.scroll = 10 ** 6
    save()


def zone_problems():
    s, w, c = S.items["spikes"], S.items["wing"], S.items["coin"]
    out = {"spikes": [], "wing": [], "coin": []}
    if not finite(s["x1"], s["x2"], s["h"]):
        out["spikes"].append("Fill in all three.")
    else:
        if s["x1"] < 10 or s["x2"] > 40:
            out["spikes"].append("Keep them inside 10 ≤ x ≤ 40.")
        ln = s["x2"] - s["x1"]
        if ln < 20 or ln > 30:
            out["spikes"].append("They are %d long; they need to be 20 to 30 long." % ln)
    if not finite(w["x"], w["w"], w["b"], w["h"]):
        out["wing"].append("Fill in all four.")
    else:
        if w["x"] < 42 or w["x"] + w["w"] > 54:
            out["wing"].append("Keep it inside 42 ≤ x ≤ 54.")
        if w["b"] < 3 or w["b"] > 16:
            out["wing"].append("The bottom has to be from y = 3 to 16.")
    if not c["type"] or not finite(c["x"], c["w"], c["b"], c["h"]):
        out["coin"].append("Fill in all five.")
    else:
        if c["x"] < 66 or c["x"] + c["w"] > 86:
            out["coin"].append("Keep it inside 66 ≤ x ≤ 86.")
        if c["type"] == "air" and (c["b"] < 5 or c["b"] > 16):
            out["coin"].append("An air coin's bottom has to be from y = 5 to 16.")
        if c["type"] == "under" and (c["b"] + c["h"] > 0 or c["b"] < -12):
            out["coin"].append("An underground coin's top has to be 0 or lower and its bottom −12 or higher.")
    return out


def items_ok():
    z = zone_problems()
    return not (z["spikes"] or z["wing"] or z["coin"])


def start_game():
    if items_ok():
        S.placed = True
        S.msgs = []
        FOCUS[0] = eq_field
        save()


# ----------------------------------------------------------------------------
# Save / load (browser localStorage under pygbag, a JSON file on desktop)
# ----------------------------------------------------------------------------
SAVE_KEY = "parabola-platformer-pygame-v1"
SAVE_FILE = "parabola_platformer_save.json"


def save():
    data = json.dumps({
        "placed": S.placed, "items": S.items, "view": S.view, "mode": S.mode, "zones": S.zones,
        "main": [dict(k="walk" if p["kind"] == "walk" else "jump", e=p["eqText"], x=p["endText"]) for p in S.paths["main"]],
        "booster": [dict(k="line", e=p["eqText"], x=p["endText"]) for p in S.paths["booster"]],
    })
    try:
        if sys.platform == "emscripten":
            import platform as _pf
            _pf.window.localStorage.setItem(SAVE_KEY, data)
        else:
            with open(SAVE_FILE, "w") as fh:
                fh.write(data)
    except Exception:
        pass


def load():
    raw = None
    try:
        if sys.platform == "emscripten":
            import platform as _pf
            raw = _pf.window.localStorage.getItem(SAVE_KEY)
        else:
            with open(SAVE_FILE) as fh:
                raw = fh.read()
    except Exception:
        raw = None
    if not raw:
        return
    try:
        d = json.loads(str(raw))
    except Exception:
        return
    for g, vals in (d.get("items") or {}).items():
        if g in S.items:
            for k, v in vals.items():
                if k in S.items[g]:
                    S.items[g][k] = v
    for key, (g, k) in ITEM_KEYS.items():
        v = S.items[g][k]
        item_fields[key].text = "" if v is None else str(v)
        item_fields[key].cur = len(item_fields[key].text)
    if d.get("view") in VIEWS:
        S.view = d["view"]
    S.zones = bool(d.get("zones", True))
    S.placed = bool(d.get("placed")) and items_ok()
    if S.placed:
        for m in ("main", "booster"):
            for r in d.get(m) or []:
                pc, err = build_piece(m, r.get("k", "jump"), r.get("e", ""), r.get("x", ""))
                if err:
                    break
                res = simulate(pc)
                if not res["ok"]:
                    break
                pc["samples"] = res["samples"]
                pc["collected"] = res["collected"]
                pc["yEnd"] = pc["f"](pc["xEnd"])
                S.paths[m].append(pc)
        if d.get("mode") == "booster":
            S.mode = "booster"


# ----------------------------------------------------------------------------
# Animation
# ----------------------------------------------------------------------------
def start_anim(segs, replay_all):
    lst = []
    for s in segs:
        sm = s["samples"]
        cum = [0.0]
        for i in range(1, len(sm)):
            cum.append(cum[-1] + math.hypot(sm[i][0] - sm[i - 1][0], sm[i][1] - sm[i - 1][1]))
        lst.append(dict(seg=s, cum=cum, total=cum[-1]))
    S.anim = dict(list=lst, i=0, d=0.0, replay=replay_all, ids={id(s) for s in segs})


def anim_step(dt):
    A = S.anim
    if not A:
        return
    A["d"] += 24 * dt
    while A["i"] < len(A["list"]) and A["d"] >= A["list"][A["i"]]["total"]:
        A["d"] -= A["list"][A["i"]]["total"]
        A["i"] += 1
    if A["i"] >= len(A["list"]):
        S.anim = None


def point_at(L, d):
    sm, c = L["seg"]["samples"], L["cum"]
    lo, hi = 0, len(c) - 1
    if hi <= 0:
        return sm[0][0], sm[0][1], 0
    while hi - lo > 1:
        m = (lo + hi) // 2
        if c[m] <= d:
            lo = m
        else:
            hi = m
    span = (c[hi] - c[lo]) or 1
    t = min(1, max(0, (d - c[lo]) / span))
    return sm[lo][0] + (sm[hi][0] - sm[lo][0]) * t, sm[lo][1] + (sm[hi][1] - sm[lo][1]) * t, lo


def anim_index(seg):
    A = S.anim
    if not A or id(seg) not in A["ids"]:
        return None
    for i, L in enumerate(A["list"]):
        if L["seg"] is seg:
            return i
    return None


# ----------------------------------------------------------------------------
# Drawing helpers
# ----------------------------------------------------------------------------
HITS = []


def hit(rect, fn):
    HITS.append((pygame.Rect(rect), fn))


def card(rect, tag, tag_color):
    r = pygame.Rect(rect)
    pygame.draw.rect(screen, INK, r.move(4, 4), border_radius=14)
    pygame.draw.rect(screen, CARD, r, border_radius=14)
    pygame.draw.rect(screen, INK, r, 2, border_radius=14)
    if tag:
        img = render(tag, 18, INK)
        tr = pygame.Rect(r.x + 16, r.y - 13, img.get_width() + 20, 26)
        pygame.draw.rect(screen, tag_color, tr, border_radius=7)
        pygame.draw.rect(screen, INK, tr, 2, border_radius=7)
        screen.blit(img, img.get_rect(center=tr.center))


def button(rect, label, fn, active=False, primary=False, disabled=False, sz=20, color=None, chip=False):
    r = pygame.Rect(rect)
    rad = r.h // 2 if chip else 10
    if primary:
        bg = GREYBTN if disabled else TITLE
        fg = WHITE
        if not disabled:
            pygame.draw.rect(screen, INK, r.move(4, 4), border_radius=rad)
    elif chip:
        bg = INK if active else CARD
        fg = CARD if active else INK
    else:
        bg = YELLOW if active else CARD
        fg = color or INK
        if active:
            pygame.draw.rect(screen, INK, r.move(3, 3), border_radius=rad)
    pygame.draw.rect(screen, bg, r, border_radius=rad)
    pygame.draw.rect(screen, INK, r, 2, border_radius=rad)
    c = fg if not (disabled and not primary) else (170, 165, 155)
    text(screen, label, r.center, sz, c, "center")
    if not disabled:
        hit(r, fn)


def dashed(surf, color, pts, width=3, dash=9, gap=6):
    on, left = True, dash
    for (x1, y1), (x2, y2) in zip(pts, pts[1:]):
        seg = math.hypot(x2 - x1, y2 - y1)
        if seg < 1e-6:
            continue
        pos = 0.0
        while seg - pos > 1e-6:
            step = min(left, seg - pos)
            if on:
                a = pos / seg
                b = (pos + step) / seg
                pygame.draw.line(surf, color, (x1 + (x2 - x1) * a, y1 + (y2 - y1) * a),
                                 (x1 + (x2 - x1) * b, y1 + (y2 - y1) * b), width)
            pos += step
            left -= step
            if left <= 1e-6:
                on = not on
                left = dash if on else gap


def ellipse_pts(cx, cy, rx, ry, ang, n=36):
    ca, sa = math.cos(ang), math.sin(ang)
    out = []
    for i in range(n):
        t = 2 * math.pi * i / n
        ex, ey = rx * math.cos(t), ry * math.sin(t)
        out.append((cx + ex * ca - ey * sa, cy + ex * sa + ey * ca))
    return out


def draw_coin(surf, cx, cy, r):
    lw = max(2, int(round(r * 0.16)))
    pygame.draw.circle(surf, COIN, (round(cx), round(cy)), max(2, round(r)))
    pygame.draw.circle(surf, COIN_DK, (round(cx), round(cy)), max(2, round(r)), lw)
    pygame.draw.line(surf, COIN_DK, (cx, cy - r * 0.42), (cx, cy + r * 0.42), max(2, int(round(r * 0.15))))


def draw_wing(surf, cx, cy, r):
    lw = max(2, int(round(r * 0.13)))
    for sg in (1, -1):
        pts = ellipse_pts(cx + sg * r * 0.36, cy, r * 0.44, r * 0.56, sg * 0.32)
        pygame.draw.polygon(surf, WHITE, pts)
        pygame.draw.polygon(surf, INK, pts, lw)


def draw_spike_icon(surf, x, y, w, h, n=4):
    bw = w / n
    for k in range(n):
        pts = [(x + k * bw, y + h), (x + k * bw + bw / 2, y), (x + (k + 1) * bw, y + h)]
        pygame.draw.polygon(surf, SPIKE, pts)
        pygame.draw.polygon(surf, SPIKE_DK, pts, 2)


PIP = ["..TTTT..", ".TTTTTTT", ".TSSESS.", "..SSSS..", ".OOOOOO.",
       "SOOOOOOS", ".OOOOOO.", ".BB..BB.", ".BB..BB."]
PIP_C = {"T": (47, 158, 143), "S": (242, 195, 155), "E": (29, 29, 29), "O": (240, 138, 36), "B": (59, 59, 92)}

# ----------------------------------------------------------------------------
# Map
# ----------------------------------------------------------------------------
MAP_R = pygame.Rect(20, 100, 1240, 400)
PL, PR, PT, PB = MAP_R.x + 38, MAP_R.right - 10, MAP_R.y + 8, MAP_R.bottom - 26
PLOT = pygame.Rect(PL, PT, PR - PL, PB - PT)


def px(x):
    v = VIEWS[S.view]
    return PL + (x - v["x1"]) / (v["x2"] - v["x1"]) * (PR - PL)


def py(y):
    v = VIEWS[S.view]
    return PT + (v["y2"] - y) / (v["y2"] - v["y1"]) * (PB - PT)


_static = {"key": None, "surf": None}


def static_layer():
    s = S.items["spikes"]
    key = (S.view, S.mode, S.zones, s["x1"], s["x2"], s["h"])
    if _static["key"] == key:
        return _static["surf"]
    v = VIEWS[S.view]
    ox, oy = MAP_R.x, MAP_R.y
    surf = pygame.Surface(MAP_R.size)
    surf.fill(SKY)

    def X(x):
        return px(x) - ox

    def Y(y):
        return py(y) - oy

    def rect(x1, y1, x2, y2, col, target=None):
        t = target or surf
        r = pygame.Rect(round(X(x1)), round(Y(y2)), round(X(x2)) - round(X(x1)), round(Y(y1)) - round(Y(y2)))
        pygame.draw.rect(t, col, r)

    plot_local = PLOT.move(-ox, -oy)
    surf.set_clip(plot_local)
    rect(min(v["x1"], 0), BEDROCK, START_END, 0, GROUND)
    rect(PIT_END, BEDROCK, max(v["x2"], 112), HIGH, GROUND)
    rect(v["x1"], v["y1"], v["x2"], BEDROCK, ROCK)
    rect(START_END, BEDROCK, PIT_END, LAVA_TOP, LAVA)
    yy = BEDROCK + 1
    while yy < LAVA_TOP:
        pts = []
        xx = START_END
        k = 0
        while xx <= PIT_END + 1e-6:
            pts.append((X(xx), Y(yy + (0.35 if k % 2 else 0))))
            xx += 0.5
            k += 1
        pygame.draw.lines(surf, LAVA_DK, False, pts, 2)
        yy += 1.2

    grid = pygame.Surface(MAP_R.size, pygame.SRCALPHA)
    minor_px = (PR - PL) / (v["x2"] - v["x1"])
    minor_py = (PB - PT) / (v["y2"] - v["y1"])
    for x in range(math.ceil(v["x1"]), math.floor(v["x2"]) + 1):
        if x % 5 and minor_px < 6:
            continue
        col = (60, 95, 130, 95) if x % 5 == 0 else (90, 130, 165, 45)
        pygame.draw.line(grid, col, (round(X(x)), plot_local.top), (round(X(x)), plot_local.bottom))
    for y in range(math.ceil(v["y1"]), math.floor(v["y2"]) + 1):
        if y % 5 and minor_py < 6:
            continue
        col = (60, 95, 130, 95) if y % 5 == 0 else (90, 130, 165, 45)
        pygame.draw.line(grid, col, (plot_local.left, round(Y(y))), (plot_local.right, round(Y(y))))
    surf.blit(grid, (0, 0))

    pygame.draw.line(surf, INK, (X(v["x1"]), Y(0)), (X(v["x2"]), Y(0)), 1)
    pygame.draw.line(surf, INK, (X(0), Y(v["y1"])), (X(0), Y(v["y2"])), 1)
    pygame.draw.line(surf, GRASS, (X(min(v["x1"], 0)), Y(0)), (X(START_END), Y(0)), 3)
    pygame.draw.line(surf, GRASS, (X(PIT_END), Y(HIGH)), (X(max(v["x2"], 112)), Y(HIGH)), 3)
    pygame.draw.line(surf, GROUND_DK, (X(START_END), Y(0)), (X(START_END), Y(LAVA_TOP)), 2)
    pygame.draw.line(surf, GROUND_DK, (X(PIT_END), Y(HIGH)), (X(PIT_END), Y(LAVA_TOP)), 2)

    if S.zones:
        zones = [(10, 0, 40, 2, "short spikes zone"), (42, 3, 54, 18, "wing zone"),
                 (66, 5, 86, 18, "air coin zone"), (66, -12, 86, 0, "underground coin zone")]
        zl = pygame.Surface(MAP_R.size, pygame.SRCALPHA)
        for z in zones:
            r = pygame.Rect(round(X(z[0])), round(Y(z[3])), round(X(z[2]) - X(z[0])), round(Y(z[1]) - Y(z[3])))
            pygame.draw.rect(zl, (47, 143, 134, 22), r)
        surf.blit(zl, (0, 0))
        for z in zones:
            x1, x2, y1, y2 = X(z[0]), X(z[2]), Y(z[3]), Y(z[1])
            for a, b in (((x1, y1), (x2, y1)), ((x2, y1), (x2, y2)), ((x2, y2), (x1, y2)), ((x1, y2), (x1, y1))):
                dashed(surf, ZONE, [a, b], 1, 5, 4)
            lab_y = Y(z[1]) - 12 if z[4].startswith("under") else Y(z[3]) - 9
            text(surf, z[4], ((x1 + x2) / 2, lab_y), 17, ZONE, "center")

    # pipe
    boost = S.mode == "booster"
    pipe = pygame.Surface(MAP_R.size, pygame.SRCALPHA)

    def prect(x1, y1, x2, y2, col, w=0):
        r = pygame.Rect(round(X(x1)), round(Y(y2)), round(X(x2) - X(x1)), round(Y(y1) - Y(y2)))
        pygame.draw.rect(pipe, col, r, w)

    prect(PIPE1, PIPE_BOTTOM, PIPE2, 40, PIPE)
    prect(PIPE1 + 0.3, PIPE_BOTTOM, PIPE1 + 0.7, 40, PIPE_LT)
    prect(PIPE1, PIPE_BOTTOM, PIPE2, 40, PIPE_DK, 2)
    prect(PIPE1 - 0.35, PIPE_BOTTOM, PIPE2 + 0.35, PIPE_BOTTOM + 0.7, PIPE)
    prect(PIPE1 - 0.35, PIPE_BOTTOM, PIPE2 + 0.35, PIPE_BOTTOM + 0.7, PIPE_DK, 2)
    if boost:
        pipe.set_alpha(80)
    surf.blit(pipe, (0, 0))
    if boost:
        text(surf, "pipe smashed", (X(59), Y(PIPE_BOTTOM) + 12), 17, PIPE_DK, "center")

    # spikes (booklet style)
    for sp in spike_sets():
        k = sp["x1"]
        while k < sp["x2"] - 1e-6:
            r2 = min(k + 1, sp["x2"])
            pts = [(X(k), Y(sp["base"])), (X((k + r2) / 2), Y(sp["tip"])), (X(r2), Y(sp["base"]))]
            pygame.draw.polygon(surf, SPIKE, pts)
            pygame.draw.polygon(surf, SPIKE_DK, pts, 2)
            k += 1

    # door
    dx1, dx2 = X(DOOR_X - 0.7), X(DOOR_X + 0.7)
    dy_top, dy_bot = Y(HIGH + 3), Y(HIGH)
    rx = (dx2 - dx1) / 2
    dr = pygame.Rect(round(dx1), round(dy_top), round(dx2 - dx1), round(dy_bot - dy_top))
    pygame.draw.rect(surf, DOOR, dr, border_top_left_radius=int(rx), border_top_right_radius=int(rx))
    pygame.draw.rect(surf, DOOR_DK, dr, 2, border_top_left_radius=int(rx), border_top_right_radius=int(rx))
    pygame.draw.circle(surf, DOOR_DK, (round(X(DOOR_X + 0.35)), round(Y(HIGH + 1.4))), max(2, int(rx * 0.18)))
    text(surf, "exit", (X(DOOR_X), dy_top - 9), 17, INK, "center")
    surf.set_clip(None)

    # axis labels
    pygame.draw.rect(surf, CARD, pygame.Rect(0, 0, PL - ox, MAP_R.h))
    pygame.draw.rect(surf, CARD, pygame.Rect(0, PB - oy, MAP_R.w, MAP_R.h))
    step = v["step"]
    x = math.ceil(v["x1"] / step) * step
    while x <= v["x2"]:
        text(surf, str(x).replace("-", "−"), (X(x), PB - oy + 13), 17, INK, "center")
        x += step
    y = math.ceil(v["y1"] / 5) * 5
    while y <= v["y2"]:
        text(surf, str(y).replace("-", "−"), (PL - ox - 6, Y(y)), 17, INK, "midright")
        y += 5
    _static["key"] = key
    _static["surf"] = surf
    return surf


def screen_pts(samples):
    out = []
    lx = ly = None
    for i, (x, y) in enumerate(samples):
        sx, sy = px(x), py(y)
        if lx is None or i == len(samples) - 1 or abs(sx - lx) + abs(sy - ly) >= 1.5:
            out.append((sx, sy))
            lx, ly = sx, sy
    return out


def stroke_piece(samples, kind):
    if not samples or len(samples) < 2:
        return
    pts = screen_pts(samples)
    if len(pts) < 2:
        return
    col = KIND_COLOR.get(kind, BADC)
    if kind == "walk":
        pygame.draw.lines(screen, col, False, pts, 3)
    else:
        dashed(screen, col, pts, 3)


def dot(x, y):
    c = (round(px(x)), round(py(y)))
    pygame.draw.circle(screen, WHITE, c, 4)
    pygame.draw.circle(screen, INK, c, 4, 2)


def draw_pip(x, y):
    x1, x2 = px(x - 0.45), px(x + 0.45)
    yt, yb = py(y + 1), py(y)
    cw, ch = (x2 - x1) / 8, (yb - yt) / 9
    for r, row in enumerate(PIP):
        for c, k in enumerate(row):
            if k == ".":
                continue
            pygame.draw.rect(screen, PIP_C[k], pygame.Rect(int(x1 + c * cw), int(yt + r * ch),
                                                           math.ceil(cw) + 1, math.ceil(ch) + 1))


def draw_map():
    screen.blit(static_layer(), MAP_R.topleft)
    old = screen.get_clip()
    screen.set_clip(PLOT)
    boost = S.mode == "booster"
    A = S.anim

    # which items are taken
    taken = set()
    if not boost:
        for p in S.paths["main"]:
            idx = anim_index(p)
            if idx is None or idx < A["i"]:
                taken.update(p["collected"])
            elif idx == A["i"]:
                ptx, _, _ = point_at(A["list"][idx], A["d"])
                for it in item_list():
                    if it["id"] in p["collected"] and ptx >= it["mid"]:
                        taken.add(it["id"])
    for it in item_list():
        x1, x2, y1, y2 = px(it["x"]), px(it["x"] + it["w"]), py(it["top"]), py(it["b"])
        bw, bh = x2 - x1, y2 - y1
        layer = pygame.Surface((int(bw) + 8, int(bh) + 8), pygame.SRCALPHA)
        pygame.draw.rect(layer, (31, 29, 26, 140), pygame.Rect(4, 4, round(bw), round(bh)), 1)
        cx, cy = 4 + bw / 2, 4 + bh / 2
        if it["id"] == "coin":
            draw_coin(layer, cx, cy, min(bw, bh) * 0.42)
        else:
            draw_wing(layer, cx, cy, min(bw / 1.75, bh / 1.25))
        if boost:
            layer.set_alpha(90)
        elif it["id"] in taken:
            layer.set_alpha(55)
        screen.blit(layer, (x1 - 4, y1 - 4))

    P = S.paths[S.mode]
    for p in P:
        idx = anim_index(p)
        if idx is None or idx < A["i"]:
            stroke_piece(p["samples"], p["kind"])
        elif idx == A["i"]:
            ptx, pty, li = point_at(A["list"][idx], A["d"])
            stroke_piece(list(p["samples"][:li + 1]) + [(ptx, pty)], p["kind"])
    dot(0, 0)
    for p in P:
        idx = anim_index(p)
        if idx is not None and idx >= A["i"]:
            continue
        dot(p["xEnd"], p["yEnd"])
    at = S.attempt
    if at and at["samples"]:
        sm = at["samples"]
        idx = anim_index(at)
        if idx is not None:
            ptx, pty, li = point_at(A["list"][idx], A["d"])
            sm = list(sm[:li + 1]) + [(ptx, pty)]
        stroke_piece(sm, "bad")

    hurt = False
    if A:
        L = A["list"][min(A["i"], len(A["list"]) - 1)]
        pipx, pipy, _ = point_at(L, A["d"])
    elif at and at["samples"]:
        pipx, pipy = at["samples"][-1]
        hurt = at["crash"] is not None
    else:
        st = start_of(S.mode)
        pipx, pipy = st["x"], st["y"]
    w = won(S.mode)
    if not (w and not A):
        draw_pip(pipx, pipy)
    if hurt and not A:
        text(screen, "OUCH!", (px(pipx), py(pipy + 1) - 12), 24, BADC, "center")
    if w and not A:
        text(screen, "CLEAR!" if S.mode == "main" else "BOOSTED!", (px(DOOR_X), py(HIGH + 3) - 30), 26, INK, "center")

    if S.hover:
        hx, hy = S.hover
        sx, sy = px(hx), py(hy)
        dashed(screen, (120, 116, 108), [(sx, PLOT.top), (sx, PLOT.bottom)], 1, 3, 3)
        dashed(screen, (120, 116, 108), [(PLOT.left, sy), (PLOT.right, sy)], 1, 3, 3)
        label = "(%s, %s)" % (nfmt(hx, 1), nfmt(hy, 1))
        img = render(label, 20, INK)
        bw = img.get_width() + 14
        lx, ly = sx + 10, sy - 28
        if lx + bw > PLOT.right:
            lx = sx - 10 - bw
        if ly < PLOT.top:
            ly = sy + 8
        br = pygame.Rect(lx, ly, bw, 22)
        pygame.draw.rect(screen, CARD, br)
        pygame.draw.rect(screen, INK, br, 1)
        screen.blit(img, img.get_rect(midleft=(lx + 7, ly + 11)))
    screen.set_clip(old)
    pygame.draw.rect(screen, INK, MAP_R, 2, border_radius=6)


# ----------------------------------------------------------------------------
# Screen sections
# ----------------------------------------------------------------------------
def draw_header():
    text(screen, "PRECALCULUS 11  ·  CHAPTER 4 APPLIED TASK", (22, 12), 17, TEAL)
    text(screen, "PARABOLA PLATFORMER", (24, 33), 50, INK)
    text(screen, "PARABOLA PLATFORMER", (21, 30), 50, TITLE)
    if S.placed:
        button((800, 26, 240, 38), "Main path  ·  Steps 2-5", lambda: set_mode("main"), active=S.mode == "main")
        button((1048, 26, 212, 38), "Booster  ·  Step 6", lambda: set_mode("booster"), active=S.mode == "booster")


def set_view(v):
    S.view = v
    save()


def toggle_zones():
    S.zones = not S.zones
    save()


def draw_toolbar():
    x = 20
    for key in ("full", "r1", "r2", "r3"):
        lab = VIEWS[key]["label"]
        w = font(19).size(lab)[0] + 28
        button((x, 66, w, 28), lab, lambda k=key: set_view(k), active=S.view == key, sz=19, chip=True)
        x += w + 8
    bx = 1260
    if S.placed:
        armed = time.time() - _arm["items"] < 3
        lab = "Erases Pip's path. Click again" if armed else "Move my items"
        w = font(19).size(lab)[0] + 26
        bx -= w
        button((bx, 64, w, 32), lab, edit_items, sz=19, color=BADC if armed else None)
        bx -= 12
    lab = "Show item zones"
    w = font(19).size(lab)[0] + 30
    bx -= w
    box = pygame.Rect(bx, 71, 18, 18)
    pygame.draw.rect(screen, WHITE, box, border_radius=3)
    pygame.draw.rect(screen, INK, box, 2, border_radius=3)
    if S.zones:
        pygame.draw.lines(screen, TEAL, False, [(bx + 4, 80), (bx + 8, 85), (bx + 15, 74)], 3)
    text(screen, lab, (bx + 26, 80), 19, INK, "midleft")
    hit((bx, 66, w, 28), toggle_zones)


def draw_legend():
    y = 520
    x = 22
    for lab, col, dash in (("walk", PURPLE, False), ("jump (a < 0)", PINK, True),
                           ("dig (a > 0)", BLUE, True), ("booster line", ORANGE, True)):
        if dash:
            dashed(screen, col, [(x, y), (x + 26, y)], 3, 6, 4)
        else:
            pygame.draw.line(screen, col, (x, y), (x + 26, y), 3)
        r = text(screen, lab, (x + 34, y), 18, MUTED, "midleft")
        x = r.right + 22
    P = S.paths[S.mode]
    text(screen, "%s  ·  %d piece%s" % ("Booster" if S.mode == "booster" else "Main path",
                                             len(P), "" if len(P) == 1 else "s"), (1258, y), 19, INK, "midright")


def draw_messages(x, y, w, bottom):
    for typ, head, body in S.msgs:
        border, bg = MSG_COLOR[typ]
        lines = wrap(body, 18, w - 24)
        h = 12 + (18 if head else 0) + 18 * len(lines)
        if y + h > bottom:
            break
        r = pygame.Rect(x, y, w, h)
        pygame.draw.rect(screen, bg, r, border_radius=8)
        pygame.draw.rect(screen, border, r, 2, border_radius=8)
        yy = y + 6
        if head:
            text(screen, head, (x + 12, yy), 18, border)
            yy += 18
        for ln in lines:
            text(screen, ln, (x + 12, yy), 18, INK)
            yy += 18
        y += h + 6


def preview_line(field, is_eq):
    t = field.text
    if not t.strip():
        return "", MUTED
    try:
        a = parse(t)
        if is_eq:
            return "y = " + pretty(a), INK
        if has_x(a):
            return "Use a number here, not x.", BADC
        v = ev(a, 0)
        s = "x = " + pretty(a)
        if math.isfinite(v) and not is_int(v):
            s += "     (about %s for graphing)" % nfmt(v)
        return s, INK
    except ParseError as e:
        return str(e), BADC


KEYPAD = [("x", "x", 0), ("x²", "²", 0), ("( )", "()", 1), ("√", "sqrt()", 1),
          ("a/b", "/", 0), ("−", "-", 0), ("+", "+", 0), ("del", None, 0)]


def keypad_press(ins, back):
    f = FOCUS[0]
    if f not in (eq_field, end_field):
        f = end_field if (S.mode == "main" and S.kind == "walk") else eq_field
        FOCUS[0] = f
    if ins is None:
        if f.cur > 0:
            f.text = f.text[:f.cur - 1] + f.text[f.cur:]
            f.cur -= 1
        return
    f.insert(ins)
    f.cur -= back


def set_kind(k):
    S.kind = k
    FOCUS[0] = end_field if k == "walk" else eq_field


def draw_next_move(r):
    card(r, "NEXT LINE" if S.mode == "booster" else "NEXT MOVE", MINT)
    x, y, w = r.x + 18, r.y + 22, r.w - 36
    st = start_of(S.mode)
    boost = S.mode == "booster"
    kind = "line" if boost else S.kind
    if won(S.mode):
        text(screen, "Pip is through the door. Undo a move to change the ending.", (x, y), 20, INK)
    else:
        text(screen, "Pip is at (%s, %s)." % (st["xs"], st["ys"]), (x, y), 22, INK)
    y += 32
    if boost:
        for ln in wrap("Booster: a straight line from (0, 0) to a point you choose, then a straight glide "
                       "to the door (104, 2). Items don't count and the pipe is smashed. No touching spikes, "
                       "lava or the ground.", 17, w):
            text(screen, ln, (x, y), 17, MUTED)
            y += 17
        y += 8
    else:
        bw = (w - 10) // 2
        button((x, y, bw, 38), "Walk", lambda: set_kind("walk"), active=kind == "walk", sz=22)
        button((x + bw + 10, y, bw, 38), "Jump or dig", lambda: set_kind("jump"), active=kind == "jump", sz=22)
        y += 52
    lab_w = 150
    if kind != "walk":
        text(screen, "y =", (x + lab_w - 10, y + 19), 24, INK, "midright")
        eq_field.draw((x + lab_w, y, w - lab_w, 38))
        s, c = preview_line(eq_field, True)
        text(screen, s, (x + lab_w + 4, y + 42), 20, c)
        y += 66
    lab = {"walk": "Walk to x =", "line": "Ends at x =", "jump": "Lands at x ="}[kind]
    text(screen, lab, (x + lab_w - 10, y + 19), 24, INK, "midright")
    end_field.draw((x + lab_w, y, w - lab_w, 38))
    s, c = preview_line(end_field, False)
    text(screen, s, (x + lab_w + 4, y + 42), 20, c)
    y += 68
    kx = x
    for lab, ins, back in KEYPAD:
        kw = 50
        button((kx, y, kw, 34), lab, lambda i=ins, b=back: keypad_press(i, b), sz=20)
        kx += kw + 6
    go_lab = {"walk": "WALK!", "line": "BOOST!", "jump": "JUMP / DIG!"}[kind]
    button((kx + 6, y - 2, x + w - kx - 6, 38), go_lab, go, primary=True, disabled=won(S.mode), sz=24)
    y += 42
    text(screen, "Shortcuts: (x-6)2 means (x − 6)².  sqrt(6), r6 or √6 means √6.", (x, y), 17, MUTED)
    y += 24
    draw_messages(x, y, w, r.bottom - 10)


def draw_path_panel(r):
    card(r, "PIP'S PATH", SKYTAG)
    P = S.paths[S.mode]
    x, y, w = r.x + 16, r.y + 22, r.w - 32
    head = pygame.Rect(x, y, w, 28)
    pygame.draw.rect(screen, YELLOW, head, border_top_left_radius=6, border_top_right_radius=6)
    text(screen, "#", (x + 18, y + 14), 18, INK, "center")
    text(screen, "MOVE", (x + 46, y + 14), 18, INK, "midleft")
    text(screen, "WHAT PIP DID", (x + 136, y + 14), 18, INK, "midleft")
    body = pygame.Rect(x, y + 28, w, r.bottom - 66 - (y + 28))
    pygame.draw.rect(screen, WHITE, body)
    rows = []
    for i, p in enumerate(P):
        h = 30 if p["kind"] == "walk" else 50
        rows.append((i, p, h))
    total = sum(h for _, _, h in rows)
    max_scroll = max(0, total - body.h)
    S.scroll = max(0, min(S.scroll, max_scroll))
    old = screen.get_clip()
    screen.set_clip(body)
    yy = body.y - S.scroll
    if not rows:
        text(screen, "No moves yet. Pip is waiting at (0, 0).", body.center, 19, MUTED, "center")
    for i, p, h in rows:
        rr = pygame.Rect(x, yy, w, h)
        pygame.draw.rect(screen, (251, 243, 214), (x, yy, 36, h))
        text(screen, str(i + 1), (x + 18, yy + h / 2), 20, INK, "center")
        text(screen, p["kind"].upper(), (x + 46, yy + h / 2), 18, KIND_COLOR[p["kind"]], "midleft")
        got = "   got " + " and ".join(p.get("collected", [])) if p.get("collected") else ""
        span = "from x = %s to x = %s" % (p["x0s"], p["endS"])
        if p["kind"] == "walk":
            rt = text(screen, "Walked " + span, (x + 136, yy + h / 2), 21, INK, "midleft")
            if got:
                text(screen, got, (rt.right, yy + h / 2), 18, OKC, "midleft")
        else:
            text(screen, p["eqS"], (x + 136, yy + 6), 22, INK)
            rt = text(screen, span, (x + 136, yy + 29), 18, MUTED)
            if got:
                text(screen, got, (rt.right, yy + 29), 18, OKC)
        pygame.draw.line(screen, LINE, (x, rr.bottom - 1), (x + w, rr.bottom - 1))
        yy += h
    screen.set_clip(old)
    pygame.draw.rect(screen, INK, pygame.Rect(x, y, w, body.bottom - y), 2, border_radius=6)
    if max_scroll:
        text(screen, "scroll for more", (x + w - 6, body.bottom - 4), 16, MUTED, "bottomright")
    hit(body, lambda: None)
    by = r.bottom - 52
    has = bool(P)
    button((x, by, 170, 36), "Undo last move", undo, disabled=not has, sz=20)
    button((x + 180, by, 140, 36), "Replay path", replay, disabled=not has, sz=20)
    armed = time.time() - _arm["reset"] < 3
    button((x + 330, by, 200, 36), "Click again to erase" if armed else "Start over", reset,
           disabled=not has and not S.attempt, sz=20, color=BADC)


def seg_control(x, y, w, options, value, setter):
    n = len(options)
    bw = (w - 6 * (n - 1)) / n
    for i, (lab, val) in enumerate(options):
        button((x + i * (bw + 6), y, bw, 34), lab, lambda v=val: setter(v), active=value == val, sz=20)


def set_item(g, k):
    def fn(v):
        S.items[g][k] = v
        save()
    return fn


def draw_setup(r):
    card(r, "FIRST  ·  PLACE YOUR ITEMS", YELLOW)
    x, y = r.x + 18, r.y + 22
    text(screen, "Copy your short spikes, wing and coin from your Map Design. Each one appears on the map "
                 "as you fill it in. When all three are in their zones, press OK.", (x, y), 19, MUTED)
    z = zone_problems()
    bw = (r.w - 36 - 32) // 3
    by = y + 26
    bh = r.bottom - 62 - by
    boxes = [("spikes", "Short spikes", "20 to 30 long, 1 or 2 tall, on the start ground, inside 10 ≤ x ≤ 40"),
             ("wing", "Wing", "1 or 2 wide, 1 or 2 tall, inside 42 ≤ x ≤ 54, bottom from y = 3 to 16"),
             ("coin", "Coin", "1 or 2 wide, 1 or 2 tall, inside 66 ≤ x ≤ 86. Air: bottom y = 5 to 16. "
                              "Underground: top 0 or lower, bottom −12 or higher")]
    for i, (key, title, rule) in enumerate(boxes):
        bx = x + i * (bw + 16)
        box = pygame.Rect(bx, by, bw, bh)
        pygame.draw.rect(screen, WHITE, box, border_radius=10)
        pygame.draw.rect(screen, INK, box, 2, border_radius=10)
        ix, iy = bx + 14, by + 12
        if key == "spikes":
            draw_spike_icon(screen, ix, iy + 2, 40, 22)
        elif key == "wing":
            draw_wing(screen, ix + 18, iy + 13, 14)
        else:
            draw_coin(screen, ix + 13, iy + 13, 12)
        text(screen, title, (ix + 52, iy + 13), 24, INK, "midleft")
        ry = iy + 32
        for ln in wrap(rule, 17, bw - 28):
            text(screen, ln, (ix, ry), 17, MUTED)
            ry += 17
        cy = ry + 8
        cw = (bw - 28 - 12) // 2
        c1, c2 = ix, ix + cw + 12

        def num(fkey, label, cx, cy):
            text(screen, label, (cx, cy), 17, MUTED)
            item_fields[fkey].draw((cx, cy + 18, cw, 34))

        if key == "spikes":
            num("sx1", "Left end x", c1, cy)
            num("sx2", "Right end x", c2, cy)
            text(screen, "Height", (c1, cy + 60), 17, MUTED)
            seg_control(c1, cy + 78, cw, [("1", 1), ("2", 2)], S.items["spikes"]["h"], set_item("spikes", "h"))
        elif key == "wing":
            num("wx", "Left side x", c1, cy)
            num("wb", "Bottom y", c2, cy)
            text(screen, "Width", (c1, cy + 60), 17, MUTED)
            seg_control(c1, cy + 78, cw, [("1", 1), ("2", 2)], S.items["wing"]["w"], set_item("wing", "w"))
            text(screen, "Height", (c2, cy + 60), 17, MUTED)
            seg_control(c2, cy + 78, cw, [("1", 1), ("2", 2)], S.items["wing"]["h"], set_item("wing", "h"))
        else:
            text(screen, "Where", (c1, cy), 17, MUTED)
            seg_control(c1, cy + 18, bw - 28, [("Air", "air"), ("Underground", "under")],
                        S.items["coin"]["type"], set_item("coin", "type"))
            cy2 = cy + 60
            num("cx", "Left side x", c1, cy2)
            num("cb", "Bottom y", c2, cy2)
            text(screen, "Width", (c1, cy2 + 60), 17, MUTED)
            seg_control(c1, cy2 + 78, cw, [("1", 1), ("2", 2)], S.items["coin"]["w"], set_item("coin", "w"))
            text(screen, "Height", (c2, cy2 + 60), 17, MUTED)
            seg_control(c2, cy2 + 78, cw, [("1", 1), ("2", 2)], S.items["coin"]["h"], set_item("coin", "h"))
        probs = z[key]
        sy = box.bottom - 7
        if not probs:
            text(screen, "In the zone", (ix, sy), 19, OKC, "bottomleft")
        else:
            empty = probs[0].startswith("Fill")
            lines = wrap(" ".join(probs), 17, bw - 28)
            for j, ln in enumerate(reversed(lines)):
                text(screen, ln, (ix, sy - j * 17), 17, MUTED if empty else BADC, "bottomleft")
    ok = items_ok()
    button((r.x + 18, r.bottom - 52, r.w - 36, 38), "OK, START THE GAME", start_game, primary=True,
           disabled=not ok, sz=26)


PANEL_Y = 548
LEFT_R = pygame.Rect(20, PANEL_Y, 600, H - PANEL_Y - 16)
RIGHT_R = pygame.Rect(640, PANEL_Y, 620, H - PANEL_Y - 16)
SETUP_R = pygame.Rect(20, PANEL_Y, 1240, H - PANEL_Y - 16)


def draw_all():
    HITS.clear()
    screen.fill(PAPER)
    draw_header()
    draw_toolbar()
    draw_map()
    draw_legend()
    if S.placed:
        draw_next_move(LEFT_R)
        draw_path_panel(RIGHT_R)
    else:
        draw_setup(SETUP_R)


# ----------------------------------------------------------------------------
# Main loop (async so pygbag can run it in the browser)
# ----------------------------------------------------------------------------
def all_fields():
    if S.placed:
        return [eq_field, end_field] if not (S.mode == "main" and S.kind == "walk") else [end_field]
    return [item_fields[k] for k in ("sx1", "sx2", "wx", "wb", "cx", "cb")]


def handle(events):
    typed_ti = []
    typed_kd = []
    for e in events:
        if e.type == pygame.QUIT:
            return False
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            for r, fn in reversed(HITS):
                if r.collidepoint(e.pos):
                    if not isinstance(fn, type(None)):
                        prev = FOCUS[0]
                        fn()
                        if FOCUS[0] is prev and prev is not None and not prev.rect.collidepoint(e.pos):
                            pass
                    break
            else:
                pass
        elif e.type == pygame.MOUSEWHEEL:
            if RIGHT_R.collidepoint(pygame.mouse.get_pos()):
                S.scroll -= e.y * 30
        elif e.type == pygame.MOUSEMOTION:
            if PLOT.collidepoint(e.pos):
                v = VIEWS[S.view]
                S.hover = (v["x1"] + (e.pos[0] - PL) / (PR - PL) * (v["x2"] - v["x1"]),
                           v["y2"] - (e.pos[1] - PT) / (PB - PT) * (v["y2"] - v["y1"]))
            else:
                S.hover = None
        elif e.type == pygame.TEXTINPUT:
            typed_ti.append(e.text)
        elif e.type == pygame.KEYDOWN:
            f = FOCUS[0]
            if e.key == pygame.K_TAB:
                fl = all_fields()
                if fl:
                    i = fl.index(f) if f in fl else -1
                    FOCUS[0] = fl[(i + 1) % len(fl)]
                continue
            if f is not None and f.key(e):
                continue
            if e.key == pygame.K_ESCAPE:
                FOCUS[0] = None
            elif e.unicode and e.unicode.isprintable():
                typed_kd.append(e.unicode)
    f = FOCUS[0]
    if f is not None and f in all_fields():
        s = "".join(typed_ti) if typed_ti else "".join(typed_kd)
        if s:
            f.insert(s)
    return True


async def main():
    load()
    if S.placed:
        FOCUS[0] = eq_field
    running = True
    while running:
        dt = clock.tick(60) / 1000.0
        running = handle(pygame.event.get())
        anim_step(dt)
        draw_all()
        pygame.display.flip()
        await asyncio.sleep(0)
    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
